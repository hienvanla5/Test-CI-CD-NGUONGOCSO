// src/types/farmLog.ts

export type FarmActivityType =
  | 'PLANTING'
  | 'WATERING'
  | 'FERTILIZING'
  | 'PESTICIDE'
  | 'WEEDING'
  | 'HARVESTING'
  | 'OTHER';

export interface FarmLog {
  id: string;
  productionLotId: string;
  productionLotName: string;
  activityType: FarmActivityType;
  material: string | null;
  quantity: number | null;
  unit: string | null;
  executedDate: string; // YYYY-MM-DD
  notes: string | null;
  createdByName: string;
  createdAt: string; // ISO datetime
}

export interface PageResponse<T> {
  items: T[];
  page: number;
  size: number;
  totalElements: number;
  totalPages: number;
  first: boolean;
  last: boolean;
}

export interface FarmLogQueryParams {
  productionLotId: string;
  page?: number;
  size?: number;
}
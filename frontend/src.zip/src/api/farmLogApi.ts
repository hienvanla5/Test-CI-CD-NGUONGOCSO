import apiClient from './axiosConfig';
import type { FarmLog, PageResponse, FarmLogQueryParams } from '@/types/farmLog';

export const getFarmLogs = async (
  params: FarmLogQueryParams
): Promise<PageResponse<FarmLog>> => {
  const response = await apiClient.get<{
    success: boolean;
    data: PageResponse<FarmLog>;
  }>('/farm-logs', { params });
  return response.data.data;
};